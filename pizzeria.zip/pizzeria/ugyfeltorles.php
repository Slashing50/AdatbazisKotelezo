<?php

include_once('db_fuggvenyek.php');

$v_ugyfeltorol = $_POST["ugyfeltorol"];

if ( isset($v_ugyfeltorol) ) {

    $sikeres = ugyfel_torles($v_ugyfeltorol);

    if ( $sikeres ) {
        header('Location: ugyfel.php');
    } else {
        echo 'Hiba történt a kölcsönzés törlése során';
    }

} else {
    echo 'Hiba történt a kölcsönzés törlése során';

}

?>