<?php

include_once("db_fuggvenyek.php"); // fel fugjuk használni ezeket a függvényeket

// lekérjük a POST-tal átlküldött paramétereket,
// ellenőrizzük azt is, hogy kaptak-e értéket

$v_igszam = $_POST['igszam'];
$v_veznev = $_POST['veznev'];
$v_kernev = $_POST['kernev'];
$v_telszam = $_POST['telszam'];
$v_poz = $_POST['poz'];
$v_brutto = $_POST['brutto'];

if ( isset($v_igszam) && isset($v_veznev) &&
    isset($v_kernev) && isset($v_telszam) &&
    isset($v_poz) && isset($v_brutto) ) {

    // beszúrjuk az új rekordot az adatbázisba
    dolgozo_beszur($v_igszam,$v_veznev, $v_kernev, $v_telszam,$v_poz,$v_brutto);

    // visszatérünk az index.php-re
    header("Location: dolgozo.php");

} else {
    error_log("Nincs beállítva valamely érték");

}
