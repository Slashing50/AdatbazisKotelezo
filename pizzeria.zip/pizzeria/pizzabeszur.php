<?php

include_once("db_fuggvenyek.php"); // fel fugjuk használni ezeket a függvényeket

// lekérjük a POST-tal átlküldött paramétereket,
// ellenőrizzük azt is, hogy kaptak-e értéket

$v_nev = $_POST['nev'];
$v_meret = $_POST['meret'];
$v_alap = $_POST['alap'];
$v_feltet = $_POST['feltet'];
$v_ar = $_POST['ar'];

if ( isset($v_nev) && isset($v_alap) &&
    isset($v_feltet) && isset($v_ar)  &&  isset($v_meret) ) {

    // beszúrjuk az új rekordot az adatbázisba
    pizzat_beszur($v_nev,$v_meret, $v_alap, $v_feltet , $v_ar);

    // visszatérünk az index.php-re
    header("Location: pizza.php");

} else {
    error_log("Nincs beállítva valamely érték");

}
