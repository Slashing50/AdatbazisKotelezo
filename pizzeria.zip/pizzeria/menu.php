<?php


function menu()
{
    $menustr  = '<span style="color:blue;font-weight:bold; padding:5px;">';
    $menustr .= '<a href="index.php"><h1>Főoldal</h1></a>';
    $menustr .= '</span>';

    $menustr .= '<span style="color:blue;font-weight:bold; padding:5px;">';
    $menustr .= '<a href="pizza.php"><h1>Pizzák</h1></a>';
    $menustr .= '</span>';

    $menustr .= '<span style="color:blue;font-weight:bold; padding:5px;">';
    $menustr .= '<a href="ugyfel.php"><h1>Ügyfelek</h1></a>';
    $menustr .= '</span>';

    $menustr .= '<span style="color:blue;font-weight:bold; padding:5px;">';
    $menustr .= '<a href="rendeles.php"><h1>Rendelések</h1></a>';
    $menustr .= '</span>';

    $menustr .= '<span style="color:blue;font-weight:bold; padding:5px;">';
    $menustr .= '<a href="dolgozo.php"><h1>Dolgozók</h1></a>';
    $menustr .= '</span>';

    return $menustr;
}

