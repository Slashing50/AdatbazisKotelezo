<?php
include_once('db_fuggvenyek.php');
include_once('menu.php');
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="table.css">
</head>
<body>
<header>
    <hr />
    <div class="nav">
        <?php
        echo menu();
        ?>
    </div>

    <hr/>

</header>
<div class="centering">
    <h1 style="color: black; padding-right: 30px;">Ügyfél felvitele</h1>

    <form style="padding-left: 20px;"method="POST" action="ugyfelbeszur.php" accept-charset="utf-8">

        <label style="color: black;"><h3>Igazolványszám: </h3></label>
        <input type="number" name="igszam" />
        <br>
        <br>
        <label style="color: black;"><h3>Vezetéknév: </h3></label>
        <input type="text" name="veznev" />
        <br>
        <br>
        <label style="color: black;"><h3>Keresztnév: </h3></label>
        <input type="text" name="kernev" />
        <br>
        <br>
        <label style="color: black;"><h3>Telefonszám: </h3></label>
        <input type="text" name="telszam" />
        <br>
        <br>
        <input type="submit" value="Elküld" />
    </form>
</div>
<div class="centering">
<table class="flat-table">
    <tbody>
    <tr>
        <th><h1>Vezetéknév</h1></th>
        <th><h1>Keresztnév</h1></th>
        <th><h1>Személyi igazolványszám</h1></th>
        <th><h1>Telefonszám</h1></th>
        <th><h1>Delete</h1></th>
    </tr>
            <?php

            $ugyfel = ugyfeleketLeker(); // ez egy eredményhalmazt ad vissza

            // soronként dolgozzuk fel az eredményt
            // minden sort egy asszociatív tömbben kapunk meg
            while( $egySor = mysqli_fetch_assoc($ugyfel) ) {
                echo '<tr>';
                echo '<td><h2>'. $egySor["vezetekNev"] .'</h2></td>';
                echo '<td><h2>'. $egySor["keresztNev"] .'</h2></td>';
                echo '<td><h2>'. $egySor["igazolvanySzam"] .'</h2></td>';
                echo '<td><h2>'. $egySor["telefonSzam"] .'</h2></td>';
                echo '<td><form method="POST" action="ugyfeltorles.php">
                          <input type="hidden" name="ugyfeltorol" value="'.$egySor["igazolvanySzam"].'" />
                          <input type="submit" value="Ügyfél törlése" />
                          </form></td>';
                echo '</tr>';
            }
            mysqli_free_result($ugyfel); // töröljük a listát a memóriából
            ?>
    </tbody>
</table>
</div>
<br>
<br>

</body>
</html>