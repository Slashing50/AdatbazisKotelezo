-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2022 at 11:15 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pizzeria`
--

-- --------------------------------------------------------

--
-- Table structure for table `dolgozo`
--

CREATE TABLE `dolgozo` (
  `igazolvanySzam` int(11) NOT NULL,
  `vezetekNev` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `keresztNev` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `telefonSzam` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `pozicio` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'pincér',
  `bruttoFizetes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dolgozo`
--

INSERT INTO `dolgozo` (`igazolvanySzam`, `vezetekNev`, `keresztNev`, `telefonSzam`, `pozicio`, `bruttoFizetes`) VALUES
(325, 'Magyar', 'Ábel', '06306847489', 'szakács', 450000),
(5146, 'Lakatos', 'László', '06302552654', 'futár', 275000),
(5413, 'Práger', 'Gergő', '06302513267', 'futár', 650000),
(5651, 'Hegedűs', 'Ilona', '06704145687', 'takarító', 250000),
(6123, 'Kőrösi', 'Csaba', '06301234569', 'alapanyag beszerző', 400000),
(14654, 'Rakás', 'Áron', '06301465445', 'szakács', 450000),
(15621, 'Emelő', 'Dávid', '06504865123', 'alapanyag beszerző', 400000),
(55555, 'Ötös', 'Brendon', '06306869701', 'futár', 275000),
(58412, 'Bizonyos', 'János', '064798214', 'pincér', 350000),
(65123, 'Varga', 'Gellért', '06301235487', 'futár', 650000),
(65412, 'Varga', 'Gergő', '06304566548', 'futár', 650000),
(89452, 'Bódi', 'Martin', '06504123546', 'pénztáros', 350000),
(123451, 'Illés', 'Ica', '06708456845', 'takarító', 250000),
(651231, 'Kanton', 'Roderik', '06708456541', 'szakács', 550000),
(654845, 'Kovács', 'Gergő', '06301564569', 'futár', 650000),
(654894, 'Blazovich', 'Péter', '06705412312', 'takarító', 400000),
(654981, 'Szilléry', 'Egon', '06705123547', 'szakács', 600000),
(1465480, 'Erős', 'Pista', '06205849621', 'pénztáros', 300000),
(1621479, 'Kertész', 'Attila', '06708484594', 'szakács', 450000),
(22425654, 'Tesztes', 'Elek', '06301111222', 'szakács', 450000);

-- --------------------------------------------------------

--
-- Table structure for table `pizza`
--

CREATE TABLE `pizza` (
  `id` int(11) NOT NULL,
  `nev` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `alap` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'paradicsomos',
  `feltet` varchar(255) DEFAULT 'sajt, sonka',
  `meret` int(11) NOT NULL,
  `ar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pizza`
--

INSERT INTO `pizza` (`id`, `nev`, `alap`, `feltet`, `meret`, `ar`) VALUES
(1, 'húsimádó', 'paradicsomos', 'sajt, sonka, bacon, tarja, szalámi, darálthús', 64, 6800),
(2, 'szerelem első látásra', 'paradicsomos', 'sajt, sonka, bacon, kukorica, gomba, lilahagyma', 32, 2500),
(3, 'szalámis pizza', 'paradicsomos', 'mozarella sajt, szalámi', 32, 2100),
(4, 'sonkás pizza', 'paradicsom', 'mozarella, sonka', 28, 2000),
(5, 'csípős álom', 'paradicsom', 'mozarella, sonka, szalámi, erős paprika, lilahagyma', 32, 2400),
(6, 'magyaros', 'paradicsomos', 'sajt, szalámi, csípőspaprika, vöröshagyma', 28, 2100),
(7, 'hawai', 'paradicsomos', 'sonka, kukorica, ananász, sajt', 32, 2500),
(8, 'bolondok kedvence', 'paradicsomos', 'sajt, tükörtojás, tarja', 32, 2400),
(9, 'tarjáni', 'paradicsomos', 'sajt, sonka, tarja, bacon', 28, 2600),
(10, 'tejfölös rémálom', 'tejfölös', 'sajt, sonka, bacon', 28, 2100),
(11, 'nutellás förtelem', 'nutella', 'májvacukor', 32, 2700),
(12, 'vegán', 'paradicsomos', 'tofu, paradicsom, paprika, lilahagyma', 32, 2600);

-- --------------------------------------------------------

--
-- Table structure for table `rendeles`
--

CREATE TABLE `rendeles` (
  `rendelsSzam` int(11) NOT NULL,
  `ideje` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ugyfeligSzam` int(11) NOT NULL,
  `pizzaId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rendeles`
--

INSERT INTO `rendeles` (`rendelsSzam`, `ideje`, `ugyfeligSzam`, `pizzaId`) VALUES
(1, '2022-11-27 17:30:25', 21425261, 3),
(2, '2022-11-27 18:37:19', 12345678, 6),
(3, '2022-11-27 18:37:30', 1451, 4),
(4, '2022-11-27 18:37:39', 654235, 7),
(5, '2022-11-27 18:37:48', 985145, 11),
(6, '2022-11-27 18:38:16', 65412, 9),
(7, '2022-11-27 18:38:16', 65123, 3),
(8, '2022-11-27 18:39:00', 1231235, 5),
(9, '2022-11-27 18:39:00', 10000001, 2),
(10, '2022-11-27 18:39:15', 1465840, 12),
(11, '2022-11-27 19:25:00', 1451, 5),
(12, '2022-11-27 19:25:00', 65123, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ugyfel`
--

CREATE TABLE `ugyfel` (
  `igazolvanySzam` int(11) NOT NULL,
  `vezetekNev` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `keresztNev` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `telefonSzam` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ugyfel`
--

INSERT INTO `ugyfel` (`igazolvanySzam`, `vezetekNev`, `keresztNev`, `telefonSzam`) VALUES
(1451, 'Nagynemes', 'Szabolcs', '06204471182'),
(1465, 'Sándor', 'Alex', '06704747859'),
(12332, 'Laczkovich', 'Kristóf', '06706429242'),
(62314, 'Barna', 'Gergely', '06301465487'),
(65123, 'Pósa', 'Ferenc', '06301236544'),
(65412, 'Varga', 'Balázs', '06305665545'),
(65421, 'Varga', 'Tamás', '06706548984'),
(65423, 'Kovács', 'Alex', '06305447895'),
(152621, 'Kis', 'Miklós', '06306570495'),
(423156, 'Kovács', 'Norbert Ákos', '06706969420'),
(654235, 'Kurunczi', 'Nándor', '06708456549'),
(985145, 'Somogyi', 'István', '06709874562'),
(1231235, 'Biztos', 'Kata', '06209845214'),
(1233211, 'Vicci', 'Elekes', '06201233212'),
(1465178, 'Klauzáltér', 'Bolondja', '06706894251'),
(1465840, 'József', 'Attila', '06301454479'),
(10000001, 'Tóbiás', 'Ezékiel', '06501123213'),
(12345676, 'Elekes', 'József', '062012332121'),
(12345678, 'Bicok', 'Norbert', '06306296251'),
(21425261, 'Teszt', 'Sándor', '06301234567');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dolgozo`
--
ALTER TABLE `dolgozo`
  ADD PRIMARY KEY (`igazolvanySzam`);

--
-- Indexes for table `pizza`
--
ALTER TABLE `pizza`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rendeles`
--
ALTER TABLE `rendeles`
  ADD PRIMARY KEY (`rendelsSzam`),
  ADD KEY `tartozik` (`pizzaId`),
  ADD KEY `rendel` (`ugyfeligSzam`);

--
-- Indexes for table `ugyfel`
--
ALTER TABLE `ugyfel`
  ADD PRIMARY KEY (`igazolvanySzam`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pizza`
--
ALTER TABLE `pizza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `rendeles`
--
ALTER TABLE `rendeles`
  MODIFY `rendelsSzam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rendeles`
--
ALTER TABLE `rendeles`
  ADD CONSTRAINT `rendel` FOREIGN KEY (`ugyfeligSzam`) REFERENCES `ugyfel` (`igazolvanySzam`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tartozik` FOREIGN KEY (`pizzaId`) REFERENCES `pizza` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
