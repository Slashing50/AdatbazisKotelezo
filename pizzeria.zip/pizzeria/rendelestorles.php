<?php

include_once('db_fuggvenyek.php');

$v_rendtorles = $_POST["rendtorol"];

if ( isset($v_rendtorles) ) {

    $sikeres = rendeles_torles($v_rendtorles);

    if ( $sikeres ) {
        header('Location: rendeles.php');
    } else {
        echo 'Hiba történt a kölcsönzés törlése során';
    }

} else {
    echo 'Hiba történt a kölcsönzés törlése során';

}

?>
