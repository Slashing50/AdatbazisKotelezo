<?php

include_once("db_fuggvenyek.php"); // fel fugjuk használni ezeket a függvényeket

// lekérjük a POST-tal átlküldött paramétereket,
// ellenőrizzük azt is, hogy kaptak-e értéket

$v_sorszam = $_POST['sorszam'];
$v_ideje = $_POST['ideje'];
$v_igszam = $_POST['igszam'];
$v_pizzaId = $_POST['pizzaId'];


if ( isset($v_sorszam) && isset($v_ideje) &&
    isset($v_igszam) && isset($v_pizzaId) ) {

    // beszúrjuk az új rekordot az adatbázisba
    rendeles_beszur($v_sorszam,$v_ideje, $v_igszam, $v_pizzaId);

    // visszatérünk az index.php-re
    header("Location: rendeles.php");

} else {
    error_log("Nincs beállítva valamely érték");}