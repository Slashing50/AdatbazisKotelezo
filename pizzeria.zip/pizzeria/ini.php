<?php
$app = [
        'dbname' => 'webshop',
        'user' => 'webshop',
        'host' => 'localhost',
        'dbpass' => '',
        'port' => '3306',
];