<?php

include_once('db_fuggvenyek.php');

$v_pizzatorles = $_POST["pizzatorles"];

if ( isset($v_pizzatorles) ) {

    $sikeres = pizza_torles($v_pizzatorles);

    if ( $sikeres ) {
        header('Location: pizza.php');
    } else {
        echo 'Hiba történt a kölcsönzés törlése során';
    }

} else {
    echo 'Hiba történt a kölcsönzés törlése során';

}

?>
