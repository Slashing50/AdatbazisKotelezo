<?php

include_once("db_fuggvenyek.php"); // fel fugjuk használni ezeket a függvényeket

// lekérjük a POST-tal átlküldött paramétereket,
// ellenőrizzük azt is, hogy kaptak-e értéket

$v_igszam = $_POST['igszam'];
$v_veznev = $_POST['veznev'];
$v_kernev = $_POST['kernev'];
$v_telszam = $_POST['telszam'];

if ( isset($v_igszam) && isset($v_veznev) &&
    isset($v_kernev) && isset($v_telszam)) {

    // beszúrjuk az új rekordot az adatbázisba
    ugyfel_beszur($v_igszam,$v_veznev, $v_kernev, $v_telszam);

    // visszatérünk az index.php-re
    header("Location: ugyfel.php");

} else {
    error_log("Nincs beállítva valamely érték");

}
