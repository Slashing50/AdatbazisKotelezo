<?php
function pizzeria_csatlakozas() {

    $conn = mysqli_connect("localhost", "root", "") or die("Csatlakozási hiba");
    if ( false == mysqli_select_db($conn, "pizzeria" )  ) {

        return null;
    }

    // a karakterek helyes megjelenítése miatt be kell állítani a karakterkódolást!
    mysqli_query($conn, 'SET NAMES UTF8');
    mysqli_query($conn, 'SET character_set_results=utf8');
    mysqli_set_charset($conn, 'utf8');

    return $conn;

}
function pizzakatLeker() {

    if ( !($conn =pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    // elokeszitjuk az utasitast
    $result = mysqli_query( $conn,"SELECT id, nev, meret, alap, feltet, ar FROM pizza");

    mysqli_close($conn);
    return $result;

}function ugyfeleketLeker() {

    if ( !($conn =pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    // elokeszitjuk az utasitast
    $result = mysqli_query( $conn,"SELECT igazolvanySzam, vezetekNev, keresztNev, telefonSzam FROM ugyfel");

    mysqli_close($conn);
    return $result;

}
function rendeleseketLeker() {

    if ( !($conn =pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    // elokeszitjuk az utasitast
    $result = mysqli_query( $conn,"SELECT rendelsSzam, ideje, ugyfeligSzam, pizzaId FROM rendeles");

    mysqli_close($conn);
    return $result;

}
function dolgozokatLeker() {

    if ( !($conn =pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    // elokeszitjuk az utasitast
    $result = mysqli_query( $conn,"SELECT igazolvanySzam, vezetekNev, keresztNev, telefonSzam, pozicio, bruttoFizetes FROM dolgozo");

    mysqli_close($conn);
    return $result;

}
function pizzat_beszur($nev,$meret,$alap, $feltet, $ar) {


    if ( !($conn = pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }


    // elokeszitjuk az utasitast
    $stmt = mysqli_prepare( $conn,"INSERT INTO pizza(nev, meret, alap, feltet, ar) VALUES (?,?, ?, ?, ?)");

    // bekotjuk a parametereket (igy biztonsagosabb az adatkezeles)
    mysqli_stmt_bind_param($stmt, "sdssd", $nev,$meret, $alap, $feltet, $ar);

    // lefuttatjuk az SQL utasitast
    $sikeres = mysqli_stmt_execute($stmt);
    // ez logikai erteket ad vissza, ami megmondja, hogy sikerult-e
    // vegrehajtani az utasitast

    mysqli_close($conn);
    return $sikeres;
}
function ugyfel_beszur($igszam,$veznev,$kernev, $telszam) {


    if ( !($conn = pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }


    // elokeszitjuk az utasitast
    $stmt = mysqli_prepare( $conn,"INSERT INTO ugyfel(igazolvanySzam, vezetekNev, keresztNev, telefonSzam) VALUES (?, ?, ?, ?)");

    // bekotjuk a parametereket (igy biztonsagosabb az adatkezeles)
    mysqli_stmt_bind_param($stmt, "dsss", $igszam,$veznev, $kernev, $telszam);

    // lefuttatjuk az SQL utasitast
    $sikeres = mysqli_stmt_execute($stmt);
    // ez logikai erteket ad vissza, ami megmondja, hogy sikerult-e
    // vegrehajtani az utasitast

    mysqli_close($conn);
    return $sikeres;
}
function rendeles_beszur($sorszam,$ideje,$igszam, $pizzaId) {


    if ( !($conn = pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }


    // elokeszitjuk az utasitast
    $stmt = mysqli_prepare( $conn,"INSERT INTO rendeles(rendelsSzam, ideje, ugyfeligSzam, pizzaId) VALUES (?, ?, ?, ?)");

    // bekotjuk a parametereket (igy biztonsagosabb az adatkezeles)
    mysqli_stmt_bind_param($stmt, "dsss", $sorszam,$ideje, $igszam, $pizzaId);

    // lefuttatjuk az SQL utasitast
    $sikeres = mysqli_stmt_execute($stmt);
    // ez logikai erteket ad vissza, ami megmondja, hogy sikerult-e
    // vegrehajtani az utasitast

    mysqli_close($conn);
    return $sikeres;
}
function dolgozo_beszur($igszam,$veznev,$kernev, $telszam, $poz, $brutto) {


    if ( !($conn = pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }


    // elokeszitjuk az utasitast
    $stmt = mysqli_prepare( $conn,"INSERT INTO dolgozo(igazolvanySzam, vezetekNev, keresztNev, telefonSzam, pozicio, bruttoFizetes) VALUES (?, ?, ?, ?, ?, ?)");

    // bekotjuk a parametereket (igy biztonsagosabb az adatkezeles)
    mysqli_stmt_bind_param($stmt, "dssssd", $igszam,$veznev, $kernev, $telszam,$poz,$brutto);

    // lefuttatjuk az SQL utasitast
    $sikeres = mysqli_stmt_execute($stmt);
    // ez logikai erteket ad vissza, ami megmondja, hogy sikerult-e
    // vegrehajtani az utasitast

    mysqli_close($conn);
    return $sikeres;
}
function pizza_torles($id) {

    if ( !($conn = pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    $stmt = mysqli_prepare( $conn,"DELETE FROM pizza WHERE id=?");
    mysqli_stmt_bind_param($stmt, "d", $id);


    $sikeres = mysqli_stmt_execute($stmt);

    mysqli_close($conn);
    return $sikeres;
}
function dolgozo_torles($igszam) {

    if ( !($conn = pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    $stmt = mysqli_prepare( $conn,"DELETE FROM dolgozo WHERE igazolvanySzam=?");
    mysqli_stmt_bind_param($stmt, "d", $igszam);


    $sikeres = mysqli_stmt_execute($stmt);

    mysqli_close($conn);
    return $sikeres;
}
function rendeles_torles($sorszam) {

    if ( !($conn = pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    $stmt = mysqli_prepare( $conn,"DELETE FROM rendeles WHERE rendelsSzam=?");
    mysqli_stmt_bind_param($stmt, "d", $sorszam);


    $sikeres = mysqli_stmt_execute($stmt);

    mysqli_close($conn);
    return $sikeres;
}
function ugyfel_torles($igszam) {

    if ( !($conn = pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    $stmt = mysqli_prepare( $conn,"DELETE FROM ugyfel WHERE igazolvanySzam=?");
    mysqli_stmt_bind_param($stmt, "d", $igszam);


    $sikeres = mysqli_stmt_execute($stmt);

    mysqli_close($conn);
    return $sikeres;
}

function ki_mennyit_rendelt(){

    if ( !($conn =pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    // elokeszitjuk az utasitast
    $result = mysqli_query( $conn,"SELECT COUNT(igazolvanySzam) AS mennyit, igazolvanySzam, vezetekNev, keresztNev FROM ugyfel,rendeles WHERE ugyfel.igazolvanySzam=rendeles.ugyfeligSzam GROUP BY ugyfel.igazolvanySzam");

    mysqli_close($conn);
    return $result;

}
function melyik_pizzabol_mennyi(){

    if ( !($conn =pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    // elokeszitjuk az utasitast
    $result = mysqli_query( $conn,"SELECT COUNT(id) AS mennyi,id,nev FROM pizza RIGHT JOIN rendeles ON pizza.id=rendeles.pizzaId GROUP BY id");

    mysqli_close($conn);
    return $result;

}
function ki_melyik_pizzat_rendelte(){

    if ( !($conn =pizzeria_csatlakozas()) ) { // ha nem sikerult csatlakozni, akkor kilepunk
        return false;
    }

    // elokeszitjuk az utasitast
    $result = mysqli_query( $conn,"SELECT id,nev,vezetekNev, keresztNev, igazolvanySzam FROM pizza, ugyfel, rendeles WHERE pizza.id=rendeles.pizzaId AND rendeles.ugyfeligSzam=ugyfel.igazolvanySzam GROUP BY id");

    mysqli_close($conn);
    return $result;

}