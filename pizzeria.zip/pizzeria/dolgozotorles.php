<?php

include_once('db_fuggvenyek.php');

$v_dolgtorles = $_POST["dolgtorol"];

if ( isset($v_dolgtorles) ) {

    $sikeres = dolgozo_torles($v_dolgtorles);

    if ( $sikeres ) {
        header('Location: dolgozo.php');
    } else {
        echo 'Hiba történt a kölcsönzés törlése során';
    }

} else {
    echo 'Hiba történt a kölcsönzés törlése során';

}

?>
