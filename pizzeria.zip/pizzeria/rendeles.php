<?php
include_once('db_fuggvenyek.php');
include_once('menu.php');
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="table.css">
</head>
<body>
<header>
    <hr />
    <div class="nav">
        <?php
        echo menu();
        ?>
    </div>

    <hr/>

</header>
<div class="centering">
    <h1 style="color: black; padding-right: 30px;">Rendelés felvitele</h1>

    <form style="padding-left: 20px;"method="POST" action="rendelesbeszur.php" accept-charset="utf-8">

        <label style="color: black;"><h3>Rendelés sorszáma: </h3></label>
        <input type="number" name="sorszam" />
        <br>
        <br>
        <label style="color: black;"><h3>Rendelés ideje: </h3></label>
        <input type="datetime-local" name="ideje" />
        <br>
        <br>
        <label style="color: black;"><h3>Rendelő Igazolványszáma: </h3></label>
        <select name="igszam">
            <?php
            $ugyfel = ugyfeleketLeker();
            while( $egySor = mysqli_fetch_assoc($ugyfel) ) {
                echo '<option value="'.$egySor["igazolvanySzam"].'">'.
                    $egySor["igazolvanySzam"]. ' , '.
                    $egySor["vezetekNev"]. '- ' .
                    $egySor["keresztNev"] .'</option>';
            }
            mysqli_free_result($ugyfel);
            ?>
        </select>
            <br><br>
        <label style="color: black;"><h3>Rendelt pizza azonosítója: </h3></label>
        <select name="pizzaId">
            <?php
            $pizza = pizzakatLeker();
            while( $egySor = mysqli_fetch_assoc($pizza) ) {
                echo '<option value="'.$egySor["id"].'">'.
                    $egySor["id"]. ' - '.
                    $egySor["nev"].'</option>';
            }
            mysqli_free_result($pizza);
            ?>
        </select>
        <br>
        <br>

        <input type="submit" value="Elküld" />
    </form>
</div>
<div class="centering">
    <table class="flat-table">
        <tbody>
        <tr>
            <th><h1>Sorszáma</h1></th>
            <th><h1>Rendelés ideje</h1></th>
            <th><h1>Rendelő igazolványszáma</h1></th>
            <th><h1>Rendelt pizza azonosítója</h1></th>
            <th><h1>Delete</h1></th>
        </tr>
        <?php

        $rendeles = rendeleseketLeker(); // ez egy eredményhalmazt ad vissza

        // soronként dolgozzuk fel az eredményt
        // minden sort egy asszociatív tömbben kapunk meg
        while( $egySor = mysqli_fetch_assoc($rendeles) ) {
            echo '<tr>';
            echo '<td><h2>'. $egySor["rendelsSzam"] .'</h2></td>';
            echo '<td><h2>'. $egySor["ideje"] .'</h2></td>';
            echo '<td><h2>'. $egySor["ugyfeligSzam"] .'</h2></td>';
            echo '<td><h2>'. $egySor["pizzaId"] .'</h2></td>';
            echo '<td><form method="POST" action="rendelestorles.php">
                          <input type="hidden" name="rendtorol" value="'.$egySor["rendelsSzam"].'" />
                          <input type="submit" value="Rendeles törlése" />
                          </form></td>';
            echo '</tr>';
        }
        mysqli_free_result($rendeles); // töröljük a listát a memóriából
        ?>
        </tbody>
    </table>
</div>
<br>
<br>

<div class="centering">
    <table class="flat-table">
        <tbody>
        <tr>
            <th><h1>Igazolványszám</h1></th>
            <th><h1>Vezetéknév</h1></th>
            <th><h1>Keresztnév</h1></th>
            <th><h1>Mennyi pizzát rendelt</h1></th>
        </tr>
        <?php

        $mennyit = ki_mennyit_rendelt(); // ez egy eredményhalmazt ad vissza

        // soronként dolgozzuk fel az eredményt
        // minden sort egy asszociatív tömbben kapunk meg
        while( $egySor = mysqli_fetch_assoc($mennyit) ) {
            echo '<tr>';
            echo '<td><h2>'. $egySor["igazolvanySzam"] .'</h2></td>';
            echo '<td><h2>'. $egySor["vezetekNev"] .'</h2></td>';
            echo '<td><h2>'. $egySor["keresztNev"] .'</h2></td>';
            echo '<td><h2>'. $egySor["mennyit"] .'</h2></td>';

        }
        mysqli_free_result($mennyit); // töröljük a listát a memóriából
        ?>
        </tbody>
    </table>
</div>
<div class="centering">
    <br><br>
    <table class="flat-table">
        <tbody>
        <tr>
            <th><h1>Pizza azonosítója</h1></th>
            <th><h1>Pizza neve</h1></th>
            <th><h1>Mennyit rendeltek belőle</h1></th>
        </tr>
        <?php

        $mennyi = melyik_pizzabol_mennyi(); // ez egy eredményhalmazt ad vissza

        // soronként dolgozzuk fel az eredményt
        // minden sort egy asszociatív tömbben kapunk meg
        while( $egySor = mysqli_fetch_assoc($mennyi) ) {
            echo '<tr>';
            echo '<td><h2>'. $egySor["id"] .'</h2></td>';
            echo '<td><h2>'. $egySor["nev"] .'</h2></td>';
            echo '<td><h2>'. $egySor["mennyi"] .'</h2></td>';

        }
        mysqli_free_result($mennyi); // töröljük a listát a memóriából
        ?>
        </tbody>
    </table>
</div>
<div class="centering">
    <br><br>
    <table class="flat-table">
        <tbody>
        <tr>
            <th><h1>Pizza neve</h1></th>
            <th><h1>Rendelő vezetékneve</h1></th>
            <th><h1>Rendelő keresztneve</h1>
        </tr>
        <?php

        $kimelyik = ki_melyik_pizzat_rendelte(); // ez egy eredményhalmazt ad vissza

        // soronként dolgozzuk fel az eredményt
        // minden sort egy asszociatív tömbben kapunk meg
        while( $egySor = mysqli_fetch_assoc($kimelyik) ) {
            echo '<tr>';
            echo '<td><h2>'. $egySor["nev"] .'</h2></td>';
            echo '<td><h2>'. $egySor["vezetekNev"] .'</h2></td>';
            echo '<td><h2>'. $egySor["keresztNev"] .'</h2></td>';

        }
        mysqli_free_result($kimelyik); // töröljük a listát a memóriából
        ?>
        </tbody>
    </table>
</div>

</body>
</html>